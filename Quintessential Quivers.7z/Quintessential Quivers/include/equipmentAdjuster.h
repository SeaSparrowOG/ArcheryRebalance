#pragma once

namespace Adjuster {

	bool AdjustArrows();
	bool AdjustBolts();
	bool AdjustBows();
	bool AdjustCrossbows();
}