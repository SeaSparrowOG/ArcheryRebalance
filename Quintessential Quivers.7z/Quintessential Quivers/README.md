A simple SKSE plugin designed to make arrow choice important.
With this plugin installed, the damage of arrows/bolts will be
added to the base damage of bows/crossbows.

REQUIREMENTS: 
1. Address Library for SKSE Plugins
2. SKSE64